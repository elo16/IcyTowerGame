function Bricks(descr) {
this.setup(descr);
    
}

Bricks.prototype = new Entity(true);

Bricks.prototype.width = 50;
Bricks.prototype.height = 25;

Bricks.prototype.rend = function (ctx) {
    // (cx, cy) is the centre; must offset it for drawing
   //ctx.save();
    ctx.fillStyle = this.color;
    ctx.fillRect(this.cx,
                 this.cy,
                 (this.width),
                 (this.height));
    
        //ctx.restore();
};


//i hverri röð fær brick random staðsetningu.
function randomBrickPosition(){
	var brickPosition = Math.random()*8+1;
	brickPosition = Math.round(brickPosition)
	return brickPosition;
}

//hver brick fær akveðna lengd her.
function randomBrickLength(position){
	var brickWidth;
	if(position < 10){
		brickWidth = (Math.random()*2)+2;
	}
	brickWidth = Math.round(brickWidth);
	return brickWidth;
}

var cols =12;
var rows = 6;
var aBrick = new Array(cols);
var heightBetweenBricks = 100;

function makeBricks(){
	var lengthOfBrick;
	for (var i = 0; i < rows; i++) {
		aBrick[i] = new Array(rows);
		var brickPosition = randomBrickPosition();
		lengthOfBrick = 0;
		
		for (var j = 1; j < cols-1; j++) { //byrjar i 1 og cols-1 ut af veggjunum.
			
			if (brickPosition === j) {
				lengthOfBrick = randomBrickLength(j); //segir til um hvar næsti brick á að byrja að teiknast
			}

			if(lengthOfBrick > 0){  //allir bricks sem a að teikna
	            aBrick[i][j] = new Bricks({
	            cx : j*Bricks.prototype.width,
	            cy : i*heightBetweenBricks,
	            color : "black",
	            lives : 1,
	            brickAlive : true //brickAlive segir til um hverjir eru teiknaðir og hverjir ekki
	        });
	            console.log("cy er : "+ aBrick[i][j].cy+ "    cx er : "+ aBrick[i][j].cx);
            }else{                  //allir bricks sem a ekki að teikna
            	aBrick[i][j] = new Bricks({
	            cx : j*Bricks.prototype.width,
	            cy : i*heightBetweenBricks,
	            color : "blue",
	            lives : 1,
	            brickAlive : false
	            });
            }

            lengthOfBrick--;  //takmarkar það hvað hver brick getur verið langur.

        }
	};
}


makeBricks();  //makes the bricks


function drawEveryBrick(ctx){
        for (var i = 0; i < rows; i++) {
        	 for (var j = 1; j < cols-1; j++) {
            if (aBrick[i][j].brickAlive) {
                aBrick[i][j].rend(ctx);
            };
        }
    }
}


Bricks.prototype.render = function(ctx){
    drawEveryBrick(ctx);
}

Bricks.prototype.update = function(du){

}


Bricks.isColliding = function(guyX,guyY){
    for(var i = 0; i < rows; i++){
        for(var j = 1; j< cols-1 ; j++){
            if(guyX> aBrick[i][j].cx && guyX < aBrick[i][j].cx + Bricks.prototype.width){
                if(guyY > aBrick[i][j].cy -50 && guyY< aBrick[i][j].cy + Bricks.prototype.height-50){
                    if(aBrick[i][j].brickAlive == true){
                    	console.log("aBrick[i][j].cy er : "+aBrick[i][j].cy+ "Bricks.prototype.height er :  "+Bricks.prototype.height);
                        return true;
                    }
                }
            }
        }
    }
    return false;
}