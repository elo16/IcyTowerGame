/*

spatialManager.js

A module which handles spatial lookup, as required for...
e.g. general collision detection.

*/

'use strict';

/* jshint browser: true, devel: true, globalstrict: true */

/*
0        1         2         3         4         5         6         7         8
12345678901234567890123456789012345678901234567890123456789012345678901234567890
*/

var spatialManager = {

// "PRIVATE" DATA

_nextSpatialID : 1, // make all valid IDs non-falsey (i.e. don't start at 0)

_entities : [],

// "PRIVATE" METHODS
//
// <none yet>


// PUBLIC METHODS

getNewSpatialID : function() {
    return this._nextSpatialID++;
},

register: function(entity) {
    var spatialID = entity.getSpatialID();
    this._entities[spatialID] = entity;
},

unregister: function(entity) {
    var spatialID = entity.getSpatialID();
    delete this._entities[spatialID];
},

findEntityInRange: function(posX, posY, radius) {

    // Two circles are in collision if the distance between their centre point
    // is less than the sum of their radii.
    var e, distance, limit;
    for (var i = 0; i != this._entities.length; i++) {
        e = this._entities[i];

        if (e) {
            distance = util.distSq(posX, posY, e.getPos().posX, e.getPos().posY);
            limit = util.square(radius + e.getRadius());

            if (distance < limit) {
                return e;
            }
        }
    }

    return false;
},

render: function(ctx) {
    var oldStyle = ctx.strokeStyle;
    ctx.strokeStyle = "red";
    
    for (var ID in this._entities) {
        var e = this._entities[ID];

        if (e.isRectangle()) {
            util.strokeBox(ctx, e.getPos().posX - (e.getWidth() / 2), e.getPos().posY -  (e.getHeight() / 2), e.getWidth(), e.getHeight());
        } else {
            util.strokeCircle(ctx, e.getPos().posX, e.getPos().posY, e.getRadius());
        }
    }
    ctx.strokeStyle = oldStyle;
}

};
